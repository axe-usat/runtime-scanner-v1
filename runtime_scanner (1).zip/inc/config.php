<?php
$av_list = array("avast"=> "waiting","eset" => "waiting","kaspersky" => "waiting","malwarebytes" => "waiting","360totalsecurity" => "waiting","norton" => "waiting","avira" => "waiting","comodo" => "waiting","bitdefender" => "waiting","mcafee" => "waiting","sophos" => "waiting");

 $connection = mysqli_connect( "localhost","root","xxxxxxxx","xxxxxxx");

 ?>
