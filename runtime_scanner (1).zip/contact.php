<html>
<style>
#navbar {
   position:fixed;
   bottom:210px;
   height:20px;
   width:100%;

}
</style>
<center>
Jabber: SexyCatGirls@exploit.im <br />
Discord: SexyCatGirls#4892

<div id="navbar">
  <a _target="blank" href="https://virtualcrypt.xyz"><img src="https://i.imgur.com/eVZxR88.png"></a><br />

  <a href="./index.php">[>>Scan<<]</a>
  <a href="./check.php">[>>Check key<<]</a>
  <a href="./contact.php">[>>Contact<<]</a>

</div>
